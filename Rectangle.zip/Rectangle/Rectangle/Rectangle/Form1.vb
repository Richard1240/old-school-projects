﻿
Public Class Form1
    Private Pformgraphic As System.Drawing.Graphics
    Private pintx As Integer = 0 'upper left
    Private pinty As Integer = 0 'upper left
    Private pintxx As Integer = 100 'lower right
    Private pintyy As Integer = 100 'lower right

    Private Sub btnBigger_Click(sender As Object, e As EventArgs) Handles btnBigger.Click
        'creates a object varible base on nthe system.drwing.graphics class
        'increase the variables by 10
        pintxx += 10
        pintyy += 10
        'creates object varible based on the pen class and sets it's color and width
        Dim mypen As New Pen(Color.Red, 3) 'creates a red pen 3 pixels wide
        'creates object varible based on teh rectangle class and puts in the corridents
        Dim myrectangle As New Rectangle(pintx, pinty, pintxx, pintyy)
        'set the form to be the area to draw on
        Pformgraphic = Me.CreateGraphics
        'clear any gtraphics already onthe frame
        Pformgraphic.Clear(SystemColors.Control)
        'call the subprocedure to draw a rectangle
        drawRec(mypen, myrectangle)
    End Sub

    Private Sub btnSmaller_Click(sender As Object, e As EventArgs) Handles btnSmaller.Click
        'creates a object varible base on nthe system.drwing.graphics class
        'decrease the variables by 10
        pintxx -= 10
        pintyy -= 10
        'creates object varible based on the pen class and sets it's color and width
        Dim mypen As New Pen(Color.Red, 3) 'creates a red pen 3 pixels wide
        'creates object varible based on teh rectangle class and puts in the corridents
        Dim myrectangle As New Rectangle(pintx, pinty, pintxx, pintyy)
        'set the form to be the area to draw on
        Pformgraphic = Me.CreateGraphics
        'clear any gtraphics already onthe frame
        Pformgraphic.Clear(SystemColors.Control)
        'call the subprocedure to draw a rectangle
        drawRec(mypen, myrectangle)
    End Sub

    Private Sub drawRec(ByVal color As Pen, ByVal shape As Rectangle)
        'draws a rectangle using color that was passed and corridinates
        Pformgraphic.DrawRectangle(color, shape)
        'cleans the pformgraphic object from memory
        Pformgraphic.Dispose()
    End Sub
End Class

