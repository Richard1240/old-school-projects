﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnBigger = New System.Windows.Forms.Button()
        Me.btnSmaller = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnBigger
        '
        Me.btnBigger.Location = New System.Drawing.Point(57, 197)
        Me.btnBigger.Name = "btnBigger"
        Me.btnBigger.Size = New System.Drawing.Size(75, 23)
        Me.btnBigger.TabIndex = 0
        Me.btnBigger.Text = "Bigger"
        Me.btnBigger.UseVisualStyleBackColor = True
        '
        'btnSmaller
        '
        Me.btnSmaller.Location = New System.Drawing.Point(183, 196)
        Me.btnSmaller.Name = "btnSmaller"
        Me.btnSmaller.Size = New System.Drawing.Size(75, 23)
        Me.btnSmaller.TabIndex = 1
        Me.btnSmaller.Text = "Smaller"
        Me.btnSmaller.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.btnSmaller)
        Me.Controls.Add(Me.btnBigger)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnBigger As Button
    Friend WithEvents btnSmaller As Button
End Class
