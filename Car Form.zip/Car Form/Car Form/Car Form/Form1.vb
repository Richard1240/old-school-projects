﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        cboPayment.Items.Add("Cash")
        cboPayment.Items.Add("Leasing")
        cboPayment.Items.Add("Financing")

    End Sub

    Private Sub btnOrder_Click(sender As Object, e As EventArgs) Handles btnOrder.Click
        Dim pstrOrder As String

        Select Case True 'checks for color
            Case radRed.Checked
                pstrOrder = pstrOrder & "Hello " & txtName.Text & ", the Car is Red with "
            Case radSilver.Checked
                pstrOrder = pstrOrder & "Hello " & txtName.Text & ", the Car is Silver with "
            Case radGold.Checked
                pstrOrder = pstrOrder & "Hello " & txtName.Text & ", the Car is Gold with "
            Case radWhite.Checked
                pstrOrder = pstrOrder & "Hello " & txtName.Text & ", the Car is White with "
        End Select

        'checks for add ons
        If chkCD.Checked Then
            pstrOrder = pstrOrder & "CD Player "
        End If

        If chkAC.Checked Then
            pstrOrder = pstrOrder & "Air Conditioning "
        End If

        If chkAntiLockBrake.Checked Then
            pstrOrder = pstrOrder & "Anti Lock Brakes "
        End If

        If chkSideAirBag.Checked Then
            pstrOrder = pstrOrder & "Side Air Bag "
        End If

        If chkHeatedSeats.Checked Then
            pstrOrder = pstrOrder & "Heated Seats "
        End If

        If chkLeather.Checked Then
            pstrOrder = pstrOrder & "Leather Interior "
        End If

        If chkDVD.Checked Then
            pstrOrder = pstrOrder & "DVD entertainment system"
        End If


        'adds the engine to the car

        pstrOrder = pstrOrder & ". You have chosen " & lstEngine.SelectedItem & " as a engine type."

        'check the combo for the payment method was choosen
        If cboPayment.SelectedIndex = 0 Then
            pstrOrder = pstrOrder & " You have choose to pay with Cash."
        ElseIf cboPayment.SelectedIndex = 1 Then
            pstrOrder = pstrOrder & " You have chosen to pay with Leasing"
        Else
            pstrOrder = pstrOrder & " You have chosen to pay with Financing"
        End If

        'shows the summary
        txtSummary.Text = pstrOrder

    End Sub
End Class
