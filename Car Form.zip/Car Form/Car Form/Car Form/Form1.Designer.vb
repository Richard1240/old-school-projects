﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtSummary = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnOrder = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboPayment = New System.Windows.Forms.ComboBox()
        Me.lstEngine = New System.Windows.Forms.ListBox()
        Me.lblEngine = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkDVD = New System.Windows.Forms.CheckBox()
        Me.chkLeather = New System.Windows.Forms.CheckBox()
        Me.chkHeatedSeats = New System.Windows.Forms.CheckBox()
        Me.chkSideAirBag = New System.Windows.Forms.CheckBox()
        Me.chkAntiLockBrake = New System.Windows.Forms.CheckBox()
        Me.chkAC = New System.Windows.Forms.CheckBox()
        Me.chkCD = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radWhite = New System.Windows.Forms.RadioButton()
        Me.radGold = New System.Windows.Forms.RadioButton()
        Me.radSilver = New System.Windows.Forms.RadioButton()
        Me.radRed = New System.Windows.Forms.RadioButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtSummary
        '
        Me.txtSummary.Location = New System.Drawing.Point(46, 359)
        Me.txtSummary.Multiline = True
        Me.txtSummary.Name = "txtSummary"
        Me.txtSummary.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtSummary.Size = New System.Drawing.Size(393, 60)
        Me.txtSummary.TabIndex = 24
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(43, 342)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 13)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Summary"
        '
        'btnOrder
        '
        Me.btnOrder.Location = New System.Drawing.Point(244, 297)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(75, 23)
        Me.btnOrder.TabIndex = 22
        Me.btnOrder.Text = "Order"
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(244, 249)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "Payment Method"
        '
        'cboPayment
        '
        Me.cboPayment.FormattingEnabled = True
        Me.cboPayment.Location = New System.Drawing.Point(244, 265)
        Me.cboPayment.Name = "cboPayment"
        Me.cboPayment.Size = New System.Drawing.Size(121, 21)
        Me.cboPayment.TabIndex = 20
        '
        'lstEngine
        '
        Me.lstEngine.FormattingEnabled = True
        Me.lstEngine.Items.AddRange(New Object() {"2.4L", "3.5L", "3.8L"})
        Me.lstEngine.Location = New System.Drawing.Point(65, 265)
        Me.lstEngine.Name = "lstEngine"
        Me.lstEngine.Size = New System.Drawing.Size(33, 56)
        Me.lstEngine.TabIndex = 19
        '
        'lblEngine
        '
        Me.lblEngine.AutoSize = True
        Me.lblEngine.Location = New System.Drawing.Point(34, 249)
        Me.lblEngine.Name = "lblEngine"
        Me.lblEngine.Size = New System.Drawing.Size(100, 13)
        Me.lblEngine.TabIndex = 18
        Me.lblEngine.Text = "Pick a Engine Type"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkDVD)
        Me.GroupBox2.Controls.Add(Me.chkLeather)
        Me.GroupBox2.Controls.Add(Me.chkHeatedSeats)
        Me.GroupBox2.Controls.Add(Me.chkSideAirBag)
        Me.GroupBox2.Controls.Add(Me.chkAntiLockBrake)
        Me.GroupBox2.Controls.Add(Me.chkAC)
        Me.GroupBox2.Controls.Add(Me.chkCD)
        Me.GroupBox2.Location = New System.Drawing.Point(197, 132)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(247, 114)
        Me.GroupBox2.TabIndex = 17
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Choose Add Ons"
        '
        'chkDVD
        '
        Me.chkDVD.AutoSize = True
        Me.chkDVD.Location = New System.Drawing.Point(16, 91)
        Me.chkDVD.Name = "chkDVD"
        Me.chkDVD.Size = New System.Drawing.Size(151, 17)
        Me.chkDVD.TabIndex = 6
        Me.chkDVD.Text = "DVD entertainment system"
        Me.chkDVD.UseVisualStyleBackColor = True
        '
        'chkLeather
        '
        Me.chkLeather.AutoSize = True
        Me.chkLeather.Location = New System.Drawing.Point(116, 69)
        Me.chkLeather.Name = "chkLeather"
        Me.chkLeather.Size = New System.Drawing.Size(97, 17)
        Me.chkLeather.TabIndex = 5
        Me.chkLeather.Text = "Leather Interior"
        Me.chkLeather.UseVisualStyleBackColor = True
        '
        'chkHeatedSeats
        '
        Me.chkHeatedSeats.AutoSize = True
        Me.chkHeatedSeats.Location = New System.Drawing.Point(116, 44)
        Me.chkHeatedSeats.Name = "chkHeatedSeats"
        Me.chkHeatedSeats.Size = New System.Drawing.Size(91, 17)
        Me.chkHeatedSeats.TabIndex = 4
        Me.chkHeatedSeats.Text = "Heated Seats"
        Me.chkHeatedSeats.UseVisualStyleBackColor = True
        '
        'chkSideAirBag
        '
        Me.chkSideAirBag.AutoSize = True
        Me.chkSideAirBag.Location = New System.Drawing.Point(116, 19)
        Me.chkSideAirBag.Name = "chkSideAirBag"
        Me.chkSideAirBag.Size = New System.Drawing.Size(78, 17)
        Me.chkSideAirBag.TabIndex = 3
        Me.chkSideAirBag.Text = "SideAirBag"
        Me.chkSideAirBag.UseVisualStyleBackColor = True
        '
        'chkAntiLockBrake
        '
        Me.chkAntiLockBrake.AutoSize = True
        Me.chkAntiLockBrake.Location = New System.Drawing.Point(16, 69)
        Me.chkAntiLockBrake.Name = "chkAntiLockBrake"
        Me.chkAntiLockBrake.Size = New System.Drawing.Size(102, 17)
        Me.chkAntiLockBrake.TabIndex = 2
        Me.chkAntiLockBrake.Text = "Anti Lock Brake"
        Me.chkAntiLockBrake.UseVisualStyleBackColor = True
        '
        'chkAC
        '
        Me.chkAC.AutoSize = True
        Me.chkAC.Location = New System.Drawing.Point(16, 44)
        Me.chkAC.Name = "chkAC"
        Me.chkAC.Size = New System.Drawing.Size(99, 17)
        Me.chkAC.TabIndex = 1
        Me.chkAC.Text = "Air Conditioning"
        Me.chkAC.UseVisualStyleBackColor = True
        '
        'chkCD
        '
        Me.chkCD.AutoSize = True
        Me.chkCD.Location = New System.Drawing.Point(16, 19)
        Me.chkCD.Name = "chkCD"
        Me.chkCD.Size = New System.Drawing.Size(73, 17)
        Me.chkCD.TabIndex = 0
        Me.chkCD.Text = "CD Player"
        Me.chkCD.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radWhite)
        Me.GroupBox1.Controls.Add(Me.radGold)
        Me.GroupBox1.Controls.Add(Me.radSilver)
        Me.GroupBox1.Controls.Add(Me.radRed)
        Me.GroupBox1.Location = New System.Drawing.Point(36, 132)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(129, 114)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select the Color"
        '
        'radWhite
        '
        Me.radWhite.AutoSize = True
        Me.radWhite.Location = New System.Drawing.Point(1, 90)
        Me.radWhite.Name = "radWhite"
        Me.radWhite.Size = New System.Drawing.Size(53, 17)
        Me.radWhite.TabIndex = 3
        Me.radWhite.TabStop = True
        Me.radWhite.Text = "White"
        Me.radWhite.UseVisualStyleBackColor = True
        '
        'radGold
        '
        Me.radGold.AutoSize = True
        Me.radGold.Location = New System.Drawing.Point(1, 66)
        Me.radGold.Name = "radGold"
        Me.radGold.Size = New System.Drawing.Size(47, 17)
        Me.radGold.TabIndex = 2
        Me.radGold.TabStop = True
        Me.radGold.Text = "Gold"
        Me.radGold.UseVisualStyleBackColor = True
        '
        'radSilver
        '
        Me.radSilver.AutoSize = True
        Me.radSilver.Location = New System.Drawing.Point(0, 42)
        Me.radSilver.Name = "radSilver"
        Me.radSilver.Size = New System.Drawing.Size(51, 17)
        Me.radSilver.TabIndex = 1
        Me.radSilver.TabStop = True
        Me.radSilver.Text = "Silver"
        Me.radSilver.UseVisualStyleBackColor = True
        '
        'radRed
        '
        Me.radRed.AutoSize = True
        Me.radRed.Location = New System.Drawing.Point(1, 18)
        Me.radRed.Name = "radRed"
        Me.radRed.Size = New System.Drawing.Size(45, 17)
        Me.radRed.TabIndex = 0
        Me.radRed.TabStop = True
        Me.radRed.Text = "Red"
        Me.radRed.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(128, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Name"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(197, 87)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 14
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(107, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(294, 32)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Dealership Car Form"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(479, 447)
        Me.Controls.Add(Me.txtSummary)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnOrder)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cboPayment)
        Me.Controls.Add(Me.lstEngine)
        Me.Controls.Add(Me.lblEngine)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtSummary As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnOrder As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents cboPayment As ComboBox
    Friend WithEvents lstEngine As ListBox
    Friend WithEvents lblEngine As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chkDVD As CheckBox
    Friend WithEvents chkLeather As CheckBox
    Friend WithEvents chkHeatedSeats As CheckBox
    Friend WithEvents chkSideAirBag As CheckBox
    Friend WithEvents chkAntiLockBrake As CheckBox
    Friend WithEvents chkAC As CheckBox
    Friend WithEvents chkCD As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radWhite As RadioButton
    Friend WithEvents radGold As RadioButton
    Friend WithEvents radSilver As RadioButton
    Friend WithEvents radRed As RadioButton
    Friend WithEvents Label2 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents Label1 As Label
End Class
