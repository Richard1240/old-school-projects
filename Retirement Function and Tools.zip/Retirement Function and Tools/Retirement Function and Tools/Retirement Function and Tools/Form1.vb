﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim dblIntrest As Double 'holds the interest rate
        Dim intYear As Integer 'holds how many years until retirement
        Dim dblTotal As Integer 'how many years you have to save
        Dim Intretireage As Integer 'at what age you want to retire

        If txtInterest.Text > 1 Then 'see if the whole number was entered
            dblIntrest = CDbl(txtInterest.Text) / 100 'convert to decimal
        Else
            dblIntrest = CDbl(txtInterest.Text)
        End If

        Intretireage = CInt(txtRetire.Text) 'get the age of retirement
        intYear = Intretireage - CInt(txtAge.Text) 'how many year util we retire

        dblTotal = Pmt(dblIntrest, intYear, 0, -(CInt(txtGoal.Text))) 'pass the rate of return, number of year, inital value, returns the amount per year we have to save, 
        'how much we want for retirement 
        lblTotal.Text = "You need to save " & Format(dblTotal / 12, "$#,###.00") & " per month to reach your goal." 'display the amount needed for each month

    End Sub
End Class
