﻿Public Class Scuba_Diving
    Private Sub btnCalcTotal_Click(sender As Object, e As EventArgs) Handles btnCalcTotal.Click
        'Constant for the price per operson for this package
        Const decSCUBA_PRICE_PER_PERSON As Decimal = 3000D

        'local variables
        Dim intNumberPeople As Integer 'number of people
        Dim decDiscount As Decimal 'amount of discount
        Dim decTotal As Decimal 'total cost

        Try
            'get the number of people
            intNumberPeople = CInt(txtNumberPeople.Text)
            'get the total before any discount is applied
            decTotal = intNumberPeople * decSCUBA_PRICE_PER_PERSON

            'determine whether a dicount cvan be given
            If intNumberPeople >= g_intMINIMUM_FOR_DISCOUNT Then
                'get the amount of thediscount

                decDiscount = CalcDiscount(decTotal)

                'subtract the discount from the total
                decTotal = decTotal - decDiscount
            Else
                'the discount is zero
                decDiscount = 0D
            End If
            'display the results
            lblDiscount.Text = decDiscount.ToString("c")
            lblTotal.Text = decTotal.ToString("c")
        Catch ex As Exception
            'error messafe for invalid input
            MessageBox.Show("enter a valid integer for a number of people")
        End Try
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        'clear the text boxes and display labels
        txtNumberPeople.Clear()
        lblDiscount.Text = String.Empty
        lblTotal.Text = String.Empty
        'reset the focus
        txtNumberPeople.Focus()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'close the form
        Me.Close()
    End Sub
End Class