﻿Public Class MainForm
    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        'closes the form
        Me.Close()
    End Sub

    Private Sub mnuPackagesScuba_Click(sender As Object, e As EventArgs) Handles mnuPackagesScuba.Click
        'creat an instance of the Scubaform
        Dim frmSkyDive As New Sky_Diving

        'display the Scuba from in modal style
        frmSkyDive.ShowDialog()
    End Sub

    Private Sub mnuPackagesSkyDiving_Click(sender As Object, e As EventArgs) Handles mnuPackagesSkyDiving.Click
        'creat an instance of the Scubaform
        Dim frmScuba As New Scuba_Diving

        'display the Scuba from in modal style
        frmScuba.ShowDialog()
    End Sub

    Private Sub mnuHelpAbout_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click
        'display a simple about box
        MessageBox.Show("High Adventure Travel Price Quote System Version 1.0")
    End Sub
End Class
