﻿Module PriceCalcModule
    'global constants
    Public Const g_intMINIMUM_FOR_DISCOUNT As Integer = 5
    Public Const g_decDISCOUNT_PERCENTAGE As Decimal = 0.1D

    'the cvalcdiscount function accepts the package as a total
    'as an argument and returns the amount of discount
    'for that total

    Public Function CalcDiscount(decTotal As Decimal) As Decimal
        Dim decDiscount As Decimal 'to hold the discount

        'calcuate the discount
        decDiscount = decTotal * g_decDISCOUNT_PERCENTAGE

        'return thediscount
        Return decDiscount
    End Function
End Module
