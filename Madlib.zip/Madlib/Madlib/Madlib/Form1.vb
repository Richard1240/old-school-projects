﻿Public Class Form1
    Private Sub btnStory_Click(sender As Object, e As EventArgs) Handles btnStory.Click
        Dim pstrStory As String


        'checks for any empty text boxes and exits the sub procedure if there are any empty text boxes
        If txtVerb.Text = String.Empty Then
            MessageBox.Show("Please enter text")
            Exit Sub
        ElseIf txtAdj.Text = String.Empty Then
            MessageBox.Show("Please enter text")
            Exit Sub
        ElseIf txtNoun.Text = String.Empty Then
            MessageBox.Show("Please enter text")
            Exit Sub
        ElseIf txtPNoun.Text = String.Empty Then
            MessageBox.Show("Please enter text")
            Exit Sub
        End If
        'creates the story
        pstrStory = "Hello, I used to " & txtVerb.Text & " and I was known to be " & txtAdj.Text & " and oh boy, let me tell you, I was considered to be the BEST " & txtNoun.Text &
            ". What? Don't believe me? Well if I am a liar then my name is " & txtPNoun.Text & " and you can count on that."
        'display the story
        lblStory.Text = pstrStory


    End Sub
End Class
