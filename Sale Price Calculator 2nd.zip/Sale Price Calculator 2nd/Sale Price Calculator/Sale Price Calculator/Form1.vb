﻿Public Class Form1

    Private decRetail As Decimal 'to hold the retail price
    Private decPercentage As Decimal 'to hold the discount percentage

    Private Function ValidateInputFields() As Boolean
        'try to convert each of the input fields. Return false if 
        'any field Is invalid And display a suitable error message

        If Not Decimal.TryParse(txtRetailPrice.Text, decRetail) Then
            lblMessage.Text = "Retail price must be numeric"
            Return False
        End If

        If Not Decimal.TryParse(txtDiscountPercent.Text, decPercentage) Then
            lblMessage.Text = "Discount percentage must be numeric"
            Return False
        End If
        Return True
    End Function

    Function CalculateSalePrice(ByVal decRetail As Decimal, ByVal decPercentage As Decimal) As Decimal
        'calculate and return the sale price
        Dim decSalePrice As Decimal
        decSalePrice = decRetail - (decRetail * decPercentage)
        Return decSalePrice
    End Function

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decSalePrice As Decimal

        'clear any previous message
        lblMessage.Text = String.Empty
        'if the input is valid, display the sqale price
        If ValidateInputFields() Then
            decSalePrice = CalculateSalePrice(decRetail, decPercentage)
            txtSalePrice.Text = decSalePrice.ToString("c")
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
