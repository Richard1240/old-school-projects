﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        cboDelivery.Items.Add("Delivery")
        cboDelivery.Items.Add("Pick Up")
        cboDelivery.Items.Add("Dine In")

    End Sub

    Private Sub btnOrder_Click(sender As Object, e As EventArgs) Handles btnOrder.Click
        Dim pstrOrder As String
        If chkNewUser.Checked Then 'checks if the user is a new customer
            pstrOrder = "Welcome " & txtName.Text & ", "
        Else
            pstrOrder = "Welcome back " & txtName.Text & ", "
        End If

        Select Case True 'checks for size
            Case radLarge.Checked
                pstrOrder = pstrOrder & " you have ordered a large pizza with "
            Case radMedium.Checked
                pstrOrder = pstrOrder & " you have ordered a medium pizza with "
            Case radSmall.Checked
                pstrOrder = pstrOrder & " you have ordered a small pizza with "
        End Select

        'checks for toppings
        If chkCheese.Checked Then
            pstrOrder = pstrOrder & "cheese "
        End If

        If chkPepperoni.Checked Then
            pstrOrder = pstrOrder & "pepperoni "
        End If

        If chkSausage.Checked Then
            pstrOrder = pstrOrder & "sausage "
        End If

        If chkOnion.Checked Then
            pstrOrder = pstrOrder & "onion "
        End If

        If chkGreenPepper.Checked Then
            pstrOrder = pstrOrder & "green pepper "
        End If

        If chkAnchovy.Checked Then
            pstrOrder = pstrOrder & "anchovy "
        End If

        'addds the sides to thge order

        pstrOrder = pstrOrder & ". You have chosen " & lstSide.SelectedItem & " as a side."

        'check the combo for the delivery method was choosen
        If cboDelivery.SelectedIndex = 0 Then
            pstrOrder = pstrOrder & " Your pizza will arrive in 30 minutes."
        ElseIf cboDelivery.SelectedIndex = 1 Then
            pstrOrder = pstrOrder & " Your pizza will be ready for pick up in 20 minutes."
        Else
            pstrOrder = pstrOrder & " We will have a table ready for you in 20 minutes. See you soon!"
        End If

        'shows the order
        txtOrder.Text = pstrOrder

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim objPizza As New clsPizzaOrder

        Select Case True 'checks for size
            Case radLarge.Checked
                objPizza.Size = " you have ordered a large pizza with "
            Case radMedium.Checked
                objPizza.Size = " you have ordered a medium pizza with "
            Case radSmall.Checked
                objPizza.Size = " you have ordered a small pizza with "
        End Select

        If cboDelivery.SelectedIndex = 0 Then 'checks for delivery method
            objPizza.Delivery = " Your pizza will arrive in 30 minutes."
        ElseIf cboDelivery.SelectedIndex = 1 Then
            objPizza.Delivery = " Your pizza will be ready for pick up in 20 minutes."
        Else
            objPizza.Delivery = " We will have a table ready for you in 20 minutes. See you soon!"
        End If

        If chkCheese.Checked Then 'checks for toppings
            objPizza.Topping = objPizza.Topping & "cheese "
        End If

        If chkPepperoni.Checked Then
            objPizza.Topping = objPizza.Topping & "pepperoni "
        End If

        If chkSausage.Checked Then
            objPizza.Topping = objPizza.Topping & "sausage "
        End If

        If chkOnion.Checked Then
            objPizza.Topping = objPizza.Topping & "onion "
        End If

        If chkGreenPepper.Checked Then
            objPizza.Topping = objPizza.Topping & "green pepper "
        End If

        If chkAnchovy.Checked Then
            objPizza.Topping = objPizza.Topping & "anchovy "
        End If

        If chkNewUser.Checked Then 'checks if the user is a new customer
            objPizza.User = "Welcome " & txtName.Text & ", "
        Else
            objPizza.User = "Welcome back " & txtName.Text & ", "
        End If

        objPizza.Sides = ". You have chosen " & lstSide.SelectedItem & " as a side." 'checks for sides

        txtOrder.Text = objPizza.User & objPizza.Size & objPizza.Topping & objPizza.Sides & objPizza.Delivery
        'I took out the spacing since I have it in the actual data just fine and it would cause double spacing 
    End Sub
End Class
