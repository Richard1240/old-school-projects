﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.chkNewUser = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radSmall = New System.Windows.Forms.RadioButton()
        Me.radMedium = New System.Windows.Forms.RadioButton()
        Me.radLarge = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkAnchovy = New System.Windows.Forms.CheckBox()
        Me.chkGreenPepper = New System.Windows.Forms.CheckBox()
        Me.chkOnion = New System.Windows.Forms.CheckBox()
        Me.chkSausage = New System.Windows.Forms.CheckBox()
        Me.chkPepperoni = New System.Windows.Forms.CheckBox()
        Me.chkCheese = New System.Windows.Forms.CheckBox()
        Me.lblSide = New System.Windows.Forms.Label()
        Me.lstSide = New System.Windows.Forms.ListBox()
        Me.cboDelivery = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnOrder = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtOrder = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Old English Text MT", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(99, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(298, 34)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Richard's Pizza Town"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(105, 94)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(36, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Name"
        '
        'chkNewUser
        '
        Me.chkNewUser.AutoSize = True
        Me.chkNewUser.Location = New System.Drawing.Point(314, 94)
        Me.chkNewUser.Name = "chkNewUser"
        Me.chkNewUser.Size = New System.Drawing.Size(73, 17)
        Me.chkNewUser.TabIndex = 3
        Me.chkNewUser.Text = "New User"
        Me.chkNewUser.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radSmall)
        Me.GroupBox1.Controls.Add(Me.radMedium)
        Me.GroupBox1.Controls.Add(Me.radLarge)
        Me.GroupBox1.Location = New System.Drawing.Point(32, 135)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(129, 100)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select the Pizza Size"
        '
        'radSmall
        '
        Me.radSmall.AutoSize = True
        Me.radSmall.Location = New System.Drawing.Point(7, 68)
        Me.radSmall.Name = "radSmall"
        Me.radSmall.Size = New System.Drawing.Size(50, 17)
        Me.radSmall.TabIndex = 2
        Me.radSmall.TabStop = True
        Me.radSmall.Text = "Small"
        Me.radSmall.UseVisualStyleBackColor = True
        '
        'radMedium
        '
        Me.radMedium.AutoSize = True
        Me.radMedium.Location = New System.Drawing.Point(7, 44)
        Me.radMedium.Name = "radMedium"
        Me.radMedium.Size = New System.Drawing.Size(62, 17)
        Me.radMedium.TabIndex = 1
        Me.radMedium.TabStop = True
        Me.radMedium.Text = "Medium"
        Me.radMedium.UseVisualStyleBackColor = True
        '
        'radLarge
        '
        Me.radLarge.AutoSize = True
        Me.radLarge.Location = New System.Drawing.Point(7, 20)
        Me.radLarge.Name = "radLarge"
        Me.radLarge.Size = New System.Drawing.Size(52, 17)
        Me.radLarge.TabIndex = 0
        Me.radLarge.TabStop = True
        Me.radLarge.Text = "Large"
        Me.radLarge.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkAnchovy)
        Me.GroupBox2.Controls.Add(Me.chkGreenPepper)
        Me.GroupBox2.Controls.Add(Me.chkOnion)
        Me.GroupBox2.Controls.Add(Me.chkSausage)
        Me.GroupBox2.Controls.Add(Me.chkPepperoni)
        Me.GroupBox2.Controls.Add(Me.chkCheese)
        Me.GroupBox2.Location = New System.Drawing.Point(240, 135)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Choose Toppings"
        '
        'chkAnchovy
        '
        Me.chkAnchovy.AutoSize = True
        Me.chkAnchovy.Location = New System.Drawing.Point(103, 69)
        Me.chkAnchovy.Name = "chkAnchovy"
        Me.chkAnchovy.Size = New System.Drawing.Size(68, 17)
        Me.chkAnchovy.TabIndex = 5
        Me.chkAnchovy.Text = "Anchovy"
        Me.chkAnchovy.UseVisualStyleBackColor = True
        '
        'chkGreenPepper
        '
        Me.chkGreenPepper.AutoSize = True
        Me.chkGreenPepper.Location = New System.Drawing.Point(103, 44)
        Me.chkGreenPepper.Name = "chkGreenPepper"
        Me.chkGreenPepper.Size = New System.Drawing.Size(92, 17)
        Me.chkGreenPepper.TabIndex = 4
        Me.chkGreenPepper.Text = "Green Pepper"
        Me.chkGreenPepper.UseVisualStyleBackColor = True
        '
        'chkOnion
        '
        Me.chkOnion.AutoSize = True
        Me.chkOnion.Location = New System.Drawing.Point(103, 19)
        Me.chkOnion.Name = "chkOnion"
        Me.chkOnion.Size = New System.Drawing.Size(54, 17)
        Me.chkOnion.TabIndex = 3
        Me.chkOnion.Text = "Onion"
        Me.chkOnion.UseVisualStyleBackColor = True
        '
        'chkSausage
        '
        Me.chkSausage.AutoSize = True
        Me.chkSausage.Location = New System.Drawing.Point(16, 69)
        Me.chkSausage.Name = "chkSausage"
        Me.chkSausage.Size = New System.Drawing.Size(68, 17)
        Me.chkSausage.TabIndex = 2
        Me.chkSausage.Text = "Sausage"
        Me.chkSausage.UseVisualStyleBackColor = True
        '
        'chkPepperoni
        '
        Me.chkPepperoni.AutoSize = True
        Me.chkPepperoni.Location = New System.Drawing.Point(16, 44)
        Me.chkPepperoni.Name = "chkPepperoni"
        Me.chkPepperoni.Size = New System.Drawing.Size(74, 17)
        Me.chkPepperoni.TabIndex = 1
        Me.chkPepperoni.Text = "Pepperoni"
        Me.chkPepperoni.UseVisualStyleBackColor = True
        '
        'chkCheese
        '
        Me.chkCheese.AutoSize = True
        Me.chkCheese.Location = New System.Drawing.Point(16, 19)
        Me.chkCheese.Name = "chkCheese"
        Me.chkCheese.Size = New System.Drawing.Size(62, 17)
        Me.chkCheese.TabIndex = 0
        Me.chkCheese.Text = "Cheese"
        Me.chkCheese.UseVisualStyleBackColor = True
        '
        'lblSide
        '
        Me.lblSide.AutoSize = True
        Me.lblSide.Location = New System.Drawing.Point(30, 252)
        Me.lblSide.Name = "lblSide"
        Me.lblSide.Size = New System.Drawing.Size(61, 13)
        Me.lblSide.TabIndex = 6
        Me.lblSide.Text = "Pick a Side"
        '
        'lstSide
        '
        Me.lstSide.FormattingEnabled = True
        Me.lstSide.Items.AddRange(New Object() {"Onion Rings", "Garlic Bread", "Pitful Potato"})
        Me.lstSide.Location = New System.Drawing.Point(33, 267)
        Me.lstSide.Name = "lstSide"
        Me.lstSide.Size = New System.Drawing.Size(120, 56)
        Me.lstSide.TabIndex = 7
        '
        'cboDelivery
        '
        Me.cboDelivery.FormattingEnabled = True
        Me.cboDelivery.Location = New System.Drawing.Point(240, 268)
        Me.cboDelivery.Name = "cboDelivery"
        Me.cboDelivery.Size = New System.Drawing.Size(121, 21)
        Me.cboDelivery.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(240, 252)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Delivery Method"
        '
        'btnOrder
        '
        Me.btnOrder.Location = New System.Drawing.Point(240, 300)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(75, 23)
        Me.btnOrder.TabIndex = 10
        Me.btnOrder.Text = "Order"
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(39, 345)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Order Summary"
        '
        'txtOrder
        '
        Me.txtOrder.Location = New System.Drawing.Point(42, 362)
        Me.txtOrder.Multiline = True
        Me.txtOrder.Name = "txtOrder"
        Me.txtOrder.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtOrder.Size = New System.Drawing.Size(393, 60)
        Me.txtOrder.TabIndex = 12
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(446, 252)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "testFunction"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btnOrder
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(533, 434)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtOrder)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnOrder)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cboDelivery)
        Me.Controls.Add(Me.lstSide)
        Me.Controls.Add(Me.lblSide)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.chkNewUser)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents chkNewUser As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radSmall As RadioButton
    Friend WithEvents radMedium As RadioButton
    Friend WithEvents radLarge As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chkAnchovy As CheckBox
    Friend WithEvents chkGreenPepper As CheckBox
    Friend WithEvents chkOnion As CheckBox
    Friend WithEvents chkSausage As CheckBox
    Friend WithEvents chkPepperoni As CheckBox
    Friend WithEvents chkCheese As CheckBox
    Friend WithEvents lblSide As Label
    Friend WithEvents lstSide As ListBox
    Friend WithEvents cboDelivery As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btnOrder As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents txtOrder As TextBox
    Friend WithEvents Button1 As Button
End Class
