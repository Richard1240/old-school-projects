﻿Public Class clsPizzaOrder
    Private mstrSize As String
    Private mstrDelivery As String
    Private mstrTopping As String
    Private mstrUser As String
    Private mstrSides As String

    Public Property Size As String
        Get
            Return mstrSize 'value return to application
        End Get
        Set(value As String)
            If value = "" Then Exit Property 'makes sure the string is set
            mstrSize = value
        End Set
    End Property

    Friend Property Delivery As String
        Get
            Return mstrDelivery
        End Get
        Set(value As String)
            If value = "" Then Exit Property 'makes sure the string is set
            mstrDelivery = value
        End Set
    End Property

    Public Property Topping As String
        Get
            Return mstrTopping
        End Get
        Set(value As String)
            If value = "" Then Exit Property 'makes sure the string is set
            mstrTopping = value
        End Set
    End Property

    Public Property User As String
        Get
            Return mstrUser
        End Get
        Set(value As String)
            If value = "" Then Exit Property 'makes sure the string is set
            mstrUser = value
        End Set
    End Property

    Public Property Sides As String
        Get
            Return mstrSides
        End Get
        Set(value As String)
            If value = "" Then Exit Property 'makes sure the string is set
            mstrSides = value
        End Set
    End Property
End Class
