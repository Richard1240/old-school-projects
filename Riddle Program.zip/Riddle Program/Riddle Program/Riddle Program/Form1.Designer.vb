﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnRiddle1 = New System.Windows.Forms.Button()
        Me.btnRiddle2 = New System.Windows.Forms.Button()
        Me.btnRiddle3 = New System.Windows.Forms.Button()
        Me.btnRiddle4 = New System.Windows.Forms.Button()
        Me.btnAnswer1 = New System.Windows.Forms.Button()
        Me.btnAnswer2 = New System.Windows.Forms.Button()
        Me.btnAnswer3 = New System.Windows.Forms.Button()
        Me.btnAnswer4 = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblRiddle = New System.Windows.Forms.Label()
        Me.lblAnswer = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnRiddle1
        '
        Me.btnRiddle1.Location = New System.Drawing.Point(12, 232)
        Me.btnRiddle1.Name = "btnRiddle1"
        Me.btnRiddle1.Size = New System.Drawing.Size(75, 23)
        Me.btnRiddle1.TabIndex = 0
        Me.btnRiddle1.Text = "Riddle 1"
        Me.btnRiddle1.UseVisualStyleBackColor = True
        '
        'btnRiddle2
        '
        Me.btnRiddle2.Location = New System.Drawing.Point(123, 232)
        Me.btnRiddle2.Name = "btnRiddle2"
        Me.btnRiddle2.Size = New System.Drawing.Size(75, 23)
        Me.btnRiddle2.TabIndex = 1
        Me.btnRiddle2.Text = "Riddle 2"
        Me.btnRiddle2.UseVisualStyleBackColor = True
        '
        'btnRiddle3
        '
        Me.btnRiddle3.Location = New System.Drawing.Point(236, 232)
        Me.btnRiddle3.Name = "btnRiddle3"
        Me.btnRiddle3.Size = New System.Drawing.Size(75, 23)
        Me.btnRiddle3.TabIndex = 2
        Me.btnRiddle3.Text = "Riddle 3"
        Me.btnRiddle3.UseVisualStyleBackColor = True
        '
        'btnRiddle4
        '
        Me.btnRiddle4.Location = New System.Drawing.Point(346, 232)
        Me.btnRiddle4.Name = "btnRiddle4"
        Me.btnRiddle4.Size = New System.Drawing.Size(75, 23)
        Me.btnRiddle4.TabIndex = 3
        Me.btnRiddle4.Text = "Riddle 4"
        Me.btnRiddle4.UseVisualStyleBackColor = True
        '
        'btnAnswer1
        '
        Me.btnAnswer1.Location = New System.Drawing.Point(13, 278)
        Me.btnAnswer1.Name = "btnAnswer1"
        Me.btnAnswer1.Size = New System.Drawing.Size(75, 23)
        Me.btnAnswer1.TabIndex = 4
        Me.btnAnswer1.Text = "Answer 1"
        Me.btnAnswer1.UseVisualStyleBackColor = True
        '
        'btnAnswer2
        '
        Me.btnAnswer2.Location = New System.Drawing.Point(123, 277)
        Me.btnAnswer2.Name = "btnAnswer2"
        Me.btnAnswer2.Size = New System.Drawing.Size(75, 23)
        Me.btnAnswer2.TabIndex = 5
        Me.btnAnswer2.Text = "Answer 2"
        Me.btnAnswer2.UseVisualStyleBackColor = True
        '
        'btnAnswer3
        '
        Me.btnAnswer3.Location = New System.Drawing.Point(236, 276)
        Me.btnAnswer3.Name = "btnAnswer3"
        Me.btnAnswer3.Size = New System.Drawing.Size(75, 23)
        Me.btnAnswer3.TabIndex = 6
        Me.btnAnswer3.Text = "Answer 3"
        Me.btnAnswer3.UseVisualStyleBackColor = True
        '
        'btnAnswer4
        '
        Me.btnAnswer4.Location = New System.Drawing.Point(346, 276)
        Me.btnAnswer4.Name = "btnAnswer4"
        Me.btnAnswer4.Size = New System.Drawing.Size(75, 23)
        Me.btnAnswer4.TabIndex = 7
        Me.btnAnswer4.Text = "Answer 4"
        Me.btnAnswer4.UseVisualStyleBackColor = True
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(25, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(396, 55)
        Me.lblTitle.TabIndex = 8
        Me.lblTitle.Text = "Richard's Riddles"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRiddle
        '
        Me.lblRiddle.AutoSize = True
        Me.lblRiddle.Location = New System.Drawing.Point(41, 98)
        Me.lblRiddle.Name = "lblRiddle"
        Me.lblRiddle.Size = New System.Drawing.Size(37, 13)
        Me.lblRiddle.TabIndex = 9
        Me.lblRiddle.Text = "Riddle"
        '
        'lblAnswer
        '
        Me.lblAnswer.AutoSize = True
        Me.lblAnswer.Location = New System.Drawing.Point(41, 168)
        Me.lblAnswer.Name = "lblAnswer"
        Me.lblAnswer.Size = New System.Drawing.Size(42, 13)
        Me.lblAnswer.TabIndex = 10
        Me.lblAnswer.Text = "Answer"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(433, 313)
        Me.Controls.Add(Me.lblAnswer)
        Me.Controls.Add(Me.lblRiddle)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.btnAnswer4)
        Me.Controls.Add(Me.btnAnswer3)
        Me.Controls.Add(Me.btnAnswer2)
        Me.Controls.Add(Me.btnAnswer1)
        Me.Controls.Add(Me.btnRiddle4)
        Me.Controls.Add(Me.btnRiddle3)
        Me.Controls.Add(Me.btnRiddle2)
        Me.Controls.Add(Me.btnRiddle1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnRiddle1 As Button
    Friend WithEvents btnRiddle2 As Button
    Friend WithEvents btnRiddle3 As Button
    Friend WithEvents btnRiddle4 As Button
    Friend WithEvents btnAnswer1 As Button
    Friend WithEvents btnAnswer2 As Button
    Friend WithEvents btnAnswer3 As Button
    Friend WithEvents btnAnswer4 As Button
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblRiddle As Label
    Friend WithEvents lblAnswer As Label
End Class
