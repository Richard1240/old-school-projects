﻿Public Class Form1
    Private Sub btnRiddle1_Click(sender As Object, e As EventArgs) Handles btnRiddle1.Click
        'Show the riddle
        lblRiddle.Text = "Riddle: How can a pants pocket be empty and still have something in it?"
        'Hides the answer or previous answer
        lblAnswer.Text = "Answer:"
    End Sub

    Private Sub btnRiddle2_Click(sender As Object, e As EventArgs) Handles btnRiddle2.Click
        'Show the riddle
        lblRiddle.Text = "Riddle: If I drink, I die. If i eat, I am fine. What am I?"
        'Hides the answer or previous answer
        lblAnswer.Text = "Answer:"
    End Sub

    Private Sub btnRiddle3_Click(sender As Object, e As EventArgs) Handles btnRiddle3.Click
        'Show the riddle
        lblRiddle.Text = "Riddle: What word becomes shorter when you add two letters to it?"
        'Hides the answer or previous answer
        lblAnswer.Text = "Answer:"
    End Sub

    Private Sub btnRiddle4_Click(sender As Object, e As EventArgs) Handles btnRiddle4.Click
        'Show the riddle
        lblRiddle.Text = "Riddle: What can you catch but not throw?"
        'Hides the answer or previous answer
        lblAnswer.Text = "Answer:"
    End Sub

    Private Sub btnAnswer1_Click(sender As Object, e As EventArgs) Handles btnAnswer1.Click
        'Show the answer to the riddle
        lblAnswer.Text = "Answer: It can have a hole in it."
    End Sub

    Private Sub btnAnswer2_Click(sender As Object, e As EventArgs) Handles btnAnswer2.Click
        'Show the answer to the riddle
        lblAnswer.Text = "Answer: A fire"
    End Sub

    Private Sub btnAnswer3_Click(sender As Object, e As EventArgs) Handles btnAnswer3.Click
        'Show the answer to the riddle
        lblAnswer.Text = "Answer: Short"
    End Sub

    Private Sub btnAnswer4_Click(sender As Object, e As EventArgs) Handles btnAnswer4.Click
        'Show the answer to the riddle
        lblAnswer.Text = "Answer: A cold"
    End Sub
End Class
