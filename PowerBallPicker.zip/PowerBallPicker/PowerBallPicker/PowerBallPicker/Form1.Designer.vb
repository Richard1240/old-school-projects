﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblnum1 = New System.Windows.Forms.Label()
        Me.lblnum2 = New System.Windows.Forms.Label()
        Me.lblnum3 = New System.Windows.Forms.Label()
        Me.lblnum4 = New System.Windows.Forms.Label()
        Me.lblnum5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblPower = New System.Windows.Forms.Label()
        Me.btnPick = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(145, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "PowerBall Picker"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "WhiteBall"
        '
        'lblnum1
        '
        Me.lblnum1.AutoSize = True
        Me.lblnum1.Location = New System.Drawing.Point(24, 119)
        Me.lblnum1.Name = "lblnum1"
        Me.lblnum1.Size = New System.Drawing.Size(13, 13)
        Me.lblnum1.TabIndex = 2
        Me.lblnum1.Text = "0"
        '
        'lblnum2
        '
        Me.lblnum2.AutoSize = True
        Me.lblnum2.Location = New System.Drawing.Point(93, 119)
        Me.lblnum2.Name = "lblnum2"
        Me.lblnum2.Size = New System.Drawing.Size(13, 13)
        Me.lblnum2.TabIndex = 3
        Me.lblnum2.Text = "0"
        '
        'lblnum3
        '
        Me.lblnum3.AutoSize = True
        Me.lblnum3.Location = New System.Drawing.Point(162, 119)
        Me.lblnum3.Name = "lblnum3"
        Me.lblnum3.Size = New System.Drawing.Size(13, 13)
        Me.lblnum3.TabIndex = 4
        Me.lblnum3.Text = "0"
        '
        'lblnum4
        '
        Me.lblnum4.AutoSize = True
        Me.lblnum4.Location = New System.Drawing.Point(231, 119)
        Me.lblnum4.Name = "lblnum4"
        Me.lblnum4.Size = New System.Drawing.Size(13, 13)
        Me.lblnum4.TabIndex = 5
        Me.lblnum4.Text = "0"
        '
        'lblnum5
        '
        Me.lblnum5.AutoSize = True
        Me.lblnum5.Location = New System.Drawing.Point(300, 119)
        Me.lblnum5.Name = "lblnum5"
        Me.lblnum5.Size = New System.Drawing.Size(13, 13)
        Me.lblnum5.TabIndex = 6
        Me.lblnum5.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(24, 156)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "PowerBall"
        '
        'lblPower
        '
        Me.lblPower.AutoSize = True
        Me.lblPower.Location = New System.Drawing.Point(24, 193)
        Me.lblPower.Name = "lblPower"
        Me.lblPower.Size = New System.Drawing.Size(13, 13)
        Me.lblPower.TabIndex = 8
        Me.lblPower.Text = "0"
        '
        'btnPick
        '
        Me.btnPick.Location = New System.Drawing.Point(128, 281)
        Me.btnPick.Name = "btnPick"
        Me.btnPick.Size = New System.Drawing.Size(116, 23)
        Me.btnPick.TabIndex = 9
        Me.btnPick.Text = "Pick Numbers"
        Me.btnPick.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(381, 351)
        Me.Controls.Add(Me.btnPick)
        Me.Controls.Add(Me.lblPower)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.lblnum5)
        Me.Controls.Add(Me.lblnum4)
        Me.Controls.Add(Me.lblnum3)
        Me.Controls.Add(Me.lblnum2)
        Me.Controls.Add(Me.lblnum1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblnum1 As Label
    Friend WithEvents lblnum2 As Label
    Friend WithEvents lblnum3 As Label
    Friend WithEvents lblnum4 As Label
    Friend WithEvents lblnum5 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblPower As Label
    Friend WithEvents btnPick As Button
End Class
