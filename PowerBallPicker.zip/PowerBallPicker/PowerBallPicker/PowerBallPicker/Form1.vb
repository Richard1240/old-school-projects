﻿Public Class Form1
    Private mintNumbers(5) As Integer 'creates an array to hold the number
    Private Sub btnPick_Click(sender As Object, e As EventArgs) Handles btnPick.Click
        'creates an instance of the random number class
        Dim randomNumber As New Random
        Dim pintcounter As Integer
        'intialize the random number picker
        Randomize()
        'Do Until pintcounter = 1000 'run condition until it is true
        'Do While pintcounter < 1000 'run it condition becomes false
        For pintcounter = 1 To 1000 Step 1 'runs a certain amount of time the step is how much time a increment the varible in the loop

            'pick a random number and display it

            If pintcounter < 150 Then
                lblnum1.Text = randomNumber.Next(1, 59) 'picks a number 1-59 and displays it
                If pintcounter = 149 Then
                    mintNumbers(1) = CDec(lblnum1.Text) 'puts the first number in the array
                End If
            End If
            If pintcounter < 300 Then
                lblnum2.Text = randomNumber.Next(1, 59) 'picks a number 1-59 and displays it
                If pintcounter = 299 Then
                    pintcounter += TestDouble(CInt(lblnum2.Text))
                End If
            End If
            If pintcounter < 450 Then
                lblnum3.Text = randomNumber.Next(1, 59) 'picks a number 1-59 and displays it
                If pintcounter = 449 Then
                    pintcounter += TestDouble(CInt(lblnum3.Text))
                End If
            End If
            If pintcounter < 600 Then
                lblnum4.Text = randomNumber.Next(1, 59) 'picks a number 1-59 and displays it
                If pintcounter = 599 Then
                    pintcounter += TestDouble(CInt(lblnum4.Text))
                End If
            End If
            If pintcounter < 750 Then
                lblnum5.Text = randomNumber.Next(1, 59) 'picks a number 1-59 and displays it
                If pintcounter = 749 Then
                    pintcounter += TestDouble(CInt(lblnum5.Text))
                End If
            End If

            lblPower.Text = randomNumber.Next(1, 59) 'picks a number 1-59 and displays it
            'pintcounter += 1
            Refresh() 'force the screen to redraw or refresh
            'Loop
        Next
    End Sub
    Private Function TestDouble(ByVal intnumber As Integer) 'names the function and creates the varible number
        Select Case intnumber 'what we want to test
            Case mintNumbers(1) 'what we are testing against
                Return -1 'if true what happens
            Case mintNumbers(2)
                Return -1
            Case mintNumbers(3)
                Return -1
            Case mintNumbers(4)
                Return -1
            Case Else 'if none of the cases are true
                Return 0
        End Select
    End Function
End Class
