﻿Public Class Form1
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles picHeads.Click

    End Sub

    Private Sub btnToss_Click(sender As Object, e As EventArgs) Handles btnToss.Click
        Dim intSideUp As Integer 'to indicate which side is up
        Dim rand As New Random 'random number generater
        'get a random number in the range of 0 - 1
        '0 means tails up abd 1 means heads up
        intSideUp = rand.Next(2)

        'Display the side up
        If intSideUp = 0 Then
            '0 means tails up so display tails
            'image and hides heads image.
            picTails.Visible = True
            picHeads.Visible = False
        Else
            '1 means heads up so display heads
            'image and hides tails image.
            picTails.Visible = False
            picHeads.Visible = True
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes the form
        Me.Close()
    End Sub
End Class
