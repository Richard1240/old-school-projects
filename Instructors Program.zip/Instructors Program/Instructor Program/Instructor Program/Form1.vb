﻿Public Class Form1
    Private Sub btnDoc_Click(sender As Object, e As EventArgs) Handles btnDoc.Click
        'Changes the picture
        picInstructor.Image = My.Resources.docRiverpic
        'opens Messagebox
        MessageBox.Show("Richard Andree")
    End Sub

    Private Sub btnBrenda_Click(sender As Object, e As EventArgs) Handles btnBrenda.Click
        picInstructor.Image = My.Resources.brendaRiverland 'This is a comment
        lblName.Text = "Brenda Mandt" _
            & "This is a test"
    End Sub

    Private Sub btnBob_Click(sender As Object, e As EventArgs) Handles btnBob.Click
        picInstructor.Image = My.Resources.bobRiverland
    End Sub

    Private Sub StatusStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles lblName.ItemClicked
        lblName.Text = "Why did you click the picture?"
    End Sub
End Class
