﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDoc = New System.Windows.Forms.Button()
        Me.btnBrenda = New System.Windows.Forms.Button()
        Me.btnBob = New System.Windows.Forms.Button()
        Me.picInstructor = New System.Windows.Forms.PictureBox()
        Me.lblName = New System.Windows.Forms.StatusStrip()
        CType(Me.picInstructor, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnDoc
        '
        Me.btnDoc.Location = New System.Drawing.Point(12, 201)
        Me.btnDoc.Name = "btnDoc"
        Me.btnDoc.Size = New System.Drawing.Size(75, 23)
        Me.btnDoc.TabIndex = 0
        Me.btnDoc.Text = "Doc"
        Me.btnDoc.UseVisualStyleBackColor = True
        '
        'btnBrenda
        '
        Me.btnBrenda.Location = New System.Drawing.Point(106, 201)
        Me.btnBrenda.Name = "btnBrenda"
        Me.btnBrenda.Size = New System.Drawing.Size(75, 23)
        Me.btnBrenda.TabIndex = 1
        Me.btnBrenda.Text = "Brenda"
        Me.btnBrenda.UseVisualStyleBackColor = True
        '
        'btnBob
        '
        Me.btnBob.Location = New System.Drawing.Point(197, 201)
        Me.btnBob.Name = "btnBob"
        Me.btnBob.Size = New System.Drawing.Size(75, 23)
        Me.btnBob.TabIndex = 2
        Me.btnBob.Text = "Bob"
        Me.btnBob.UseVisualStyleBackColor = True
        '
        'picInstructor
        '
        Me.picInstructor.Image = Global.Instructor_Program.My.Resources.Resources.docRiverpic
        Me.picInstructor.Location = New System.Drawing.Point(86, 12)
        Me.picInstructor.Name = "picInstructor"
        Me.picInstructor.Size = New System.Drawing.Size(114, 160)
        Me.picInstructor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picInstructor.TabIndex = 3
        Me.picInstructor.TabStop = False
        '
        'lblName
        '
        Me.lblName.Location = New System.Drawing.Point(0, 239)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(284, 22)
        Me.lblName.TabIndex = 4
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.picInstructor)
        Me.Controls.Add(Me.btnBob)
        Me.Controls.Add(Me.btnBrenda)
        Me.Controls.Add(Me.btnDoc)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.picInstructor, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnDoc As Button
    Friend WithEvents btnBrenda As Button
    Friend WithEvents btnBob As Button
    Friend WithEvents picInstructor As PictureBox
    Friend WithEvents lblName As StatusStrip
End Class
