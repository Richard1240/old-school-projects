﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes the form
        Me.Close()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decOriginalPrice As Decimal = 0 'original price
        Dim decDiscountPercentage As Decimal = 0 'discount percentage
        Dim decDiscountAmount As Decimal = 0 'Amount of discount
        Dim decSalePrice As Decimal = 0 'sale price

        'get the item's original price
        decOriginalPrice = CDec(txtOriginalPrice.Text)

        'get the discount percent
        decDiscountPercentage = CDec(txtDiscountPercentage.Text)

        'move the percentage decimal point left 2 spaces
        decDiscountPercentage = decDiscountPercentage / 100

        'calculate the amount of discount
        decDiscountAmount = decOriginalPrice * decDiscountPercentage

        'calculate the sale price
        decSalePrice = decOriginalPrice - decDiscountAmount

        'display the sale price
        lblSalePrice.Text = decSalePrice.ToString("c")
    End Sub
End Class
