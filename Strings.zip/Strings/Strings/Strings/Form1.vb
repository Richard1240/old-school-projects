﻿Public Class Form1
    Private Sub btnTest_Click(sender As Object, e As EventArgs) Handles btnTest.Click
        Dim pintSpace As Integer '1st space that strings is
        Dim pstrString As String 'hold the string that isd being tested
        Dim pintLength As Integer 'hold the length of the entire string
        Dim pintNum As Integer 'use to hold number as needed
        Dim pstrArray() As String 'Create an array to hold strings

        If txtString.Text = String.Empty Then 'check to see if something is typed into the text box
            MessageBox.Show("You must enter some text to test")
            txtString.Focus() 'puts the cursor back into the textbox
            Exit Sub 'exit the sub so the user can type text
        End If

        pstrString = txtString.Text 'puts the string into the varible
        lblFirst.Text = pstrString(0) 'display the 1st character in the string varible
        pintLength = pstrString.Length 'get the length of the string

        lblLength.Text = pintLength

        lblLast.Text = pstrString(pintLength - 1) 'find the location of the 1st space in the string
        pintSpace = pstrString.IndexOf(" ") 'get the 1st word get the character from positino
        lblfirstWord.Text = pstrString.Substring(0, pintSpace)
        pstrArray = pstrString.Split(" ")
        pintNum = pstrArray.Length
        lbllastWord.Text = pstrArray(pintNum - 1)
    End Sub

    Private Sub btnPeriod_Click(sender As Object, e As EventArgs) Handles btnPeriod.Click
        Dim pstrString As String 'hold the string that isd being tested

        If txtString.Text = String.Empty Then 'check to see if something is typed into the text box
            MessageBox.Show("You must enter some text to test")
            txtString.Focus() 'puts the cursor back into the textbox
            Exit Sub 'exit the sub so the user can type text
        End If
        pstrString = txtString.Text 'puts the string into the varible

        If pstrString(pstrString.Length - 1) <> "." Then 'looks at the last character of the string if it is not a "."


            If pstrString(pstrString.Length - 1) = "?" Or pstrString(pstrString.Length - 1) = "!" Then
                pstrString = pstrString.Remove(pstrString.Length - 1) 'removes the last charaddcter from the string
                pstrString = pstrString & "." 'cancatintinates on a .
            Else
                pstrString = pstrString & "." 'cancatintinates on a .
            End If

        End If
        txtString.Text = pstrString
    End Sub
End Class
