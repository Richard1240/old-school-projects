﻿Public Class Form1

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close() 'close the form
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decBaseFee As Decimal 'Base mothly fee
        Dim decTotalFee As Decimal 'total membership fee
        Dim intMonths As Integer 'number of months
        Dim blnInputOk As Boolean = True

        'contants for base fees
        Const decADULT_FEE As Decimal = 40D
        Const decCHILD_FEE As Decimal = 20D
        Const decSTUDENT_FEE As Decimal = 25D
        Const decSENIOR_FEE As Decimal = 30D

        'contatn for additional fees
        Const decYOGA_FEE As Decimal = 10D
        Const decKARATE_FEE As Decimal = 30D
        Const decTRAINER_FEE As Decimal = 50D

        'validates and convert the number of months
        lblStatus.Text = String.Empty
        If Integer.TryParse(txtMonths.Text, intMonths) = False Then
            lblStatus.Text = "Months must be an integer"
            blnInputOk = False
        End If

        'validates the number of months
        If intMonths < 1 Or intMonths > 24 Then
            lblStatus.Text = "Months must be inthe range of 1 -24"
            blnInputOk = False
        End If

        If blnInputOk = True Then
            'determine the base mothly fee
            If radAdult.Checked = True Then
                decBaseFee = decADULT_FEE
            ElseIf radChild.Checked = True Then
                decBaseFee = decCHILD_FEE
            ElseIf radStudent.Checked = True Then
                decBaseFee = decSTUDENT_FEE
            ElseIf radSenior.Checked = True Then
                decBaseFee = decSENIOR_FEE
            End If
        End If

        'check for additional fees

        If chkYoga.Checked = True Then
            decBaseFee += decYOGA_FEE
        End If

        If chkKarate.Checked = True Then
            decBaseFee += decKARATE_FEE
        End If

        If chkTrainer.Checked = True Then
            decBaseFee += decTRAINER_FEE
        End If

        'calculate the total fee
        decTotalFee = decBaseFee * intMonths

        'Display the Fees
        lblMonthlyFee.Text = decBaseFee.ToString("c")
        lblTotalFee.Text = decTotalFee.ToString("c")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'reset the  Adult ratio button
        radAdult.Checked = True

        'clear the check boxes
        chkKarate.Checked = False
        chkYoga.Checked = False
        chkTrainer.Checked = False

        'clear the number of months
        txtMonths.Clear()

        'clear the fee labels
        lblMonthlyFee.Text = String.Empty
        lblTotalFee.Text = String.Empty
        lblStatus.Text = String.Empty

        'give the months the focus
        txtMonths.Focus()
    End Sub
End Class
