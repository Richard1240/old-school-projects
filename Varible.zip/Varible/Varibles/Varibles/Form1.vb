﻿Public Class Form1
    'Variables types
    'Boolean Bln ued to store true or false, 1 or 0
    'Date Dat used to store dates between 1/1/0001 to12/31/9999
    'Byte byt used to store whole numbers between 0-255
    'Short sho (also called Int16)stores whole numbers between -32,768 to 32,767
    'Integer Int (also called Int32)stores whole numbers between -2,147,483.648 to 2,147,483.648
    'Long Lng(aslo called Int64(sores whole numbers between -9,223,372,036,854,777,808 to 9,223,372,036,854,777,808
    'Single Sng stores numbers with decimal points up to seven digits to the right of the decimal point
    'Doulbe Dbl stores numbers with decimal points up to 14 digits to the right of the decimal point
    'Decimal dec stores numbers with decimal points up to 29 digits to the right of the decimal point
    'String Str stores characters up to 2 billion

    'Scopes
    'Block levle varible is used in a chuck of code
    'Procedural or local level varible can be used in only procedure in which it is declared
    'Modular or class level varible can be used in any procedure associated with the form
    'Global level varible can be used by any procedure on any form in the solution

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCheckDate.Click
        Dim lBlnTest As Boolean 'creates a boolean varible
        Dim lDatTest As Date 'creates date varible
        Dim lBytTest As Byte 'creats byte varible
        Dim lShoTest As Short 'creates short varible
        Dim lIntTest As Integer 'creates integer varible
        Dim lLngTest As Long 'creates long varible
        Dim lSngTest As Single 'creates single varible
        Dim lDblTest As Double 'creats double varible
        Dim lDecTest As Decimal 'creates decimal varible
        Dim lStrTest As String 'creates string varible
        'gives the varibles a value and display the value in the correct lable
        'with error catch
        Try 'try the code up to the catch and see if it will run
            lBlnTest = txtInput.Text
            lblBoolean.Text = lBlnTest
        Catch 'if it is an error then do this
            lblBoolean.Text = "This is not a valid Boolean"
        End Try 'end the error trap

        Try 'try the code up to the catch and see if it will run
            lDatTest = txtInput.Text
            lblDate.Text = lDatTest
        Catch 'if it is an error then do this
            lblDate.Text = "This is not a valid Date"
        End Try 'end the error trap

        Try 'try the code up to the catch and see if it will run
            lBytTest = txtInput.Text
            lblByte.Text = lBytTest
        Catch 'if it is an error then do this
            lblByte.Text = "This is not a valid Byte"
        End Try 'end the error trap

        Try 'try the code up to the catch and see if it will run
            lShoTest = txtInput.Text
            lblShort.Text = lShoTest
        Catch 'if it is an error then do this
            lblShort.Text = "This is not a valid Short"
        End Try 'end the error trap

        Try 'try the code up to the catch and see if it will run
            lIntTest = txtInput.Text
            lblInteger.Text = lIntTest
        Catch 'if it is an error then do this
            lblInteger.Text = "This is not a valid Integer"
        End Try 'end the error trap

        Try 'try the code up to the catch and see if it will run
            lLngTest = txtInput.Text
            lblLong.Text = lLngTest
        Catch 'if it is an error then do this
            lblLong.Text = "This is not a valid Long"
        End Try 'end the error trap

        Try 'try the code up to the catch and see if it will run
            lSngTest = txtInput.Text
            lblSingle.Text = lSngTest
        Catch 'if it is an error then do this
            lblSingle.Text = "This is not a valid Single"
        End Try 'end the error trap

        Try 'try the code up to the catch and see if it will run
            lDblTest = txtInput.Text
            lblDouble.Text = lDblTest
        Catch 'if it is an error then do this
            lblDouble.Text = "This is not a valid Double"
        End Try 'end the error trap

        Try 'try the code up to the catch and see if it will run
            lDecTest = txtInput.Text
            lblDecimal.Text = lDecTest
        Catch 'if it is an error then do this
            lblDecimal.Text = "This is not a valid Decimal"
        End Try 'end the error trap

        Try 'try the code up to the catch and see if it will run
            lStrTest = txtInput.Text
            lblString.Text = lStrTest
        Catch 'if it is an error then do this
            lblString.Text = "This is not a valid String"
        End Try 'end the error trap

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
