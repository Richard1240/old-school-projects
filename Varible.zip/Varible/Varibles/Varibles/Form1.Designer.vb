﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblBoolean = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblByte = New System.Windows.Forms.Label()
        Me.lblShort = New System.Windows.Forms.Label()
        Me.lblInteger = New System.Windows.Forms.Label()
        Me.lblLong = New System.Windows.Forms.Label()
        Me.lblSingle = New System.Windows.Forms.Label()
        Me.lblDouble = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.btnCheckDate = New System.Windows.Forms.Button()
        Me.lblDecimal = New System.Windows.Forms.Label()
        Me.lblString = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(221, 116)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Boolean"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(221, 140)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Date"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(221, 164)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Byte"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(221, 188)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Short"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(221, 212)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Integer"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(221, 236)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Long"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(221, 260)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(36, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Single"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(221, 284)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Double"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(221, 308)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Decimal"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(222, 330)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(34, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "String"
        '
        'lblBoolean
        '
        Me.lblBoolean.AutoSize = True
        Me.lblBoolean.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBoolean.Location = New System.Drawing.Point(422, 116)
        Me.lblBoolean.MinimumSize = New System.Drawing.Size(75, 0)
        Me.lblBoolean.Name = "lblBoolean"
        Me.lblBoolean.Size = New System.Drawing.Size(75, 15)
        Me.lblBoolean.TabIndex = 10
        Me.lblBoolean.Text = " "
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDate.Location = New System.Drawing.Point(422, 140)
        Me.lblDate.MinimumSize = New System.Drawing.Size(75, 0)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(75, 15)
        Me.lblDate.TabIndex = 11
        Me.lblDate.Text = " "
        '
        'lblByte
        '
        Me.lblByte.AutoSize = True
        Me.lblByte.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblByte.Location = New System.Drawing.Point(422, 164)
        Me.lblByte.MinimumSize = New System.Drawing.Size(75, 0)
        Me.lblByte.Name = "lblByte"
        Me.lblByte.Size = New System.Drawing.Size(75, 15)
        Me.lblByte.TabIndex = 12
        Me.lblByte.Text = " "
        '
        'lblShort
        '
        Me.lblShort.AutoSize = True
        Me.lblShort.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblShort.Location = New System.Drawing.Point(422, 188)
        Me.lblShort.MinimumSize = New System.Drawing.Size(75, 0)
        Me.lblShort.Name = "lblShort"
        Me.lblShort.Size = New System.Drawing.Size(75, 15)
        Me.lblShort.TabIndex = 13
        Me.lblShort.Text = " "
        '
        'lblInteger
        '
        Me.lblInteger.AutoSize = True
        Me.lblInteger.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblInteger.Location = New System.Drawing.Point(422, 212)
        Me.lblInteger.MinimumSize = New System.Drawing.Size(75, 0)
        Me.lblInteger.Name = "lblInteger"
        Me.lblInteger.Size = New System.Drawing.Size(75, 15)
        Me.lblInteger.TabIndex = 14
        Me.lblInteger.Text = " "
        '
        'lblLong
        '
        Me.lblLong.AutoSize = True
        Me.lblLong.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLong.Location = New System.Drawing.Point(422, 236)
        Me.lblLong.MinimumSize = New System.Drawing.Size(75, 0)
        Me.lblLong.Name = "lblLong"
        Me.lblLong.Size = New System.Drawing.Size(75, 15)
        Me.lblLong.TabIndex = 15
        Me.lblLong.Text = " "
        '
        'lblSingle
        '
        Me.lblSingle.AutoSize = True
        Me.lblSingle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSingle.Location = New System.Drawing.Point(422, 260)
        Me.lblSingle.MinimumSize = New System.Drawing.Size(75, 0)
        Me.lblSingle.Name = "lblSingle"
        Me.lblSingle.Size = New System.Drawing.Size(75, 15)
        Me.lblSingle.TabIndex = 16
        Me.lblSingle.Text = " "
        '
        'lblDouble
        '
        Me.lblDouble.AutoSize = True
        Me.lblDouble.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDouble.Location = New System.Drawing.Point(422, 284)
        Me.lblDouble.MinimumSize = New System.Drawing.Size(75, 0)
        Me.lblDouble.Name = "lblDouble"
        Me.lblDouble.Size = New System.Drawing.Size(75, 15)
        Me.lblDouble.TabIndex = 17
        Me.lblDouble.Text = " "
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(118, 406)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(111, 13)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "Enter text to be tested"
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(254, 399)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(243, 20)
        Me.txtInput.TabIndex = 19
        '
        'btnCheckDate
        '
        Me.btnCheckDate.Location = New System.Drawing.Point(302, 468)
        Me.btnCheckDate.Name = "btnCheckDate"
        Me.btnCheckDate.Size = New System.Drawing.Size(75, 23)
        Me.btnCheckDate.TabIndex = 20
        Me.btnCheckDate.Text = "Click to test"
        Me.btnCheckDate.UseVisualStyleBackColor = True
        '
        'lblDecimal
        '
        Me.lblDecimal.AutoSize = True
        Me.lblDecimal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDecimal.Location = New System.Drawing.Point(422, 308)
        Me.lblDecimal.MinimumSize = New System.Drawing.Size(75, 0)
        Me.lblDecimal.Name = "lblDecimal"
        Me.lblDecimal.Size = New System.Drawing.Size(75, 15)
        Me.lblDecimal.TabIndex = 21
        Me.lblDecimal.Text = " "
        '
        'lblString
        '
        Me.lblString.AutoSize = True
        Me.lblString.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblString.Location = New System.Drawing.Point(422, 330)
        Me.lblString.MinimumSize = New System.Drawing.Size(75, 0)
        Me.lblString.Name = "lblString"
        Me.lblString.Size = New System.Drawing.Size(75, 15)
        Me.lblString.TabIndex = 22
        Me.lblString.Text = " "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(717, 688)
        Me.Controls.Add(Me.lblString)
        Me.Controls.Add(Me.lblDecimal)
        Me.Controls.Add(Me.btnCheckDate)
        Me.Controls.Add(Me.txtInput)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.lblDouble)
        Me.Controls.Add(Me.lblSingle)
        Me.Controls.Add(Me.lblLong)
        Me.Controls.Add(Me.lblInteger)
        Me.Controls.Add(Me.lblShort)
        Me.Controls.Add(Me.lblByte)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.lblBoolean)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lblBoolean As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents lblByte As Label
    Friend WithEvents lblShort As Label
    Friend WithEvents lblInteger As Label
    Friend WithEvents lblLong As Label
    Friend WithEvents lblSingle As Label
    Friend WithEvents lblDouble As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents txtInput As TextBox
    Friend WithEvents btnCheckDate As Button
    Friend WithEvents lblDecimal As Label
    Friend WithEvents lblString As Label
End Class
