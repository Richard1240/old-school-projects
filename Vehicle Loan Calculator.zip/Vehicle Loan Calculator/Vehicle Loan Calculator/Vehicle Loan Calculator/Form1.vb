﻿Public Class Form1
    'class level constants
    Const dblMONTHS_YEAR As Double = 12 'months per year
    Const dblNEW_RATE As Double = 0.05 'onterest rate, new cars
    Const dblUSED_RATE As Double = 0.08 'Onterest rate, used cars

    'Class-level varible to hold the anual rate
    Dim dblAnnualRate As Double = dblNEW_RATE

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim dblVehicleCost As Double 'Vehicle cost
        Dim dblDownPayment As Double 'down payment
        Dim intMonths As Integer 'number of months for the loan
        Dim dblLoan As Double 'amount of the loan
        Dim dblMonthlyPayment As Double 'monthly poayment
        Dim dblInterest As Double 'interest paid for the period
        Dim dblPrincipal As Double 'principal paid for the period
        Dim intCount As Integer 'counter for the loop
        Dim strOut As String 'used to hold a line out of output
        Dim blnInputOk As Boolean = True

        'get the cehicle cost, validating at the same time.-
        If Not Double.TryParse(txtCost.Text, dblVehicleCost) Then
            lblMessage.Text = "Vehicle cost must be an number"
            blnInputOk = False
        End If

        'get the down poayment, validating at the same time
        If Not Double.TryParse(txtDownPayment.Text, dblDownPayment) Then
            lblMessage.Text = "Downpayment must be an nunmber"
            blnInputOk = False
        End If

        'get the number of months, validating at the same time
        If Not Integer.TryParse(txtMonths.Text, intMonths) Then
            lblMessage.Text = "Downpayment must be an nunmber"
            blnInputOk = False
        End If

        If blnInputOk = True Then
            'calculate the loan amount and monthly poayment
            dblLoan = dblVehicleCost - dblDownPayment
            dblMonthlyPayment = Pmt(dblAnnualRate / dblMONTHS_YEAR, intMonths, -dblLoan)


            'clear the list box and message label
            lstOutput.Items.Clear()
            lblMessage.Text = String.Empty

            For intCount = 1 To intMonths
                'calculate the interest for this period
                dblInterest = IPmt(dblAnnualRate / dblMONTHS_YEAR, intCount, intMonths, -dblLoan)

                'calculate the principal for this period.
                dblPrincipal = PPmt(dblAnnualRate / dblMONTHS_YEAR, intCount, intMonths, -dblLoan)

                'start building the output string with the month
                strOut = "Month" & intCount.ToString("d2")

                'Add the payment amount to the output string
                strOut &= ": payment = " & dblMonthlyPayment.ToString("n2")

                'add the interest amount to the output string
                strOut &= ", interest = " & dblInterest.ToString("2")

                'add the principal amount for the period
                strOut &= ", principal = " & dblPrincipal.ToString("n2")

                'add the output string to the list box
                lstOutput.Items.Add(strOut)

            Next
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'reset the interest rate
        dblAnnualRate = dblNEW_RATE

        'clear the text boxes
        txtCost.Clear()
        txtDownPayment.Clear()
        txtMonths.Clear()

        'clear the list box
        lstOutput.Items.Clear()

        'set default interest rate for new car loans
        lblAnnualRate.Text = dblNEW_RATE.ToString("p")
        radNew.Checked = True

        'clear any error messages
        lblMessage.Text = String.Empty

        'reset the focus to txtCost
        txtCost.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes the form
        Me.Close()
    End Sub

    Private Sub radNew_CheckedChanged(sender As Object, e As EventArgs) Handles radNew.CheckedChanged
        'if the new radio button is checked then
        'the use has select a car laon
        If radNew.Checked = True Then
            dblAnnualRate = dblNEW_RATE
            lblAnnualRate.Text = dblNEW_RATE.ToString("p")
            lstOutput.Items.Clear()
        End If
    End Sub

    Private Sub radUsed_CheckedChanged(sender As Object, e As EventArgs) Handles radUsed.CheckedChanged
        'if the used radio button is checked then
        'the use has select a car laon
        If radUsed.Checked = True Then
            dblAnnualRate = dblUSED_RATE
            lblAnnualRate.Text = dblUSED_RATE.ToString("p")
            lstOutput.Items.Clear()
        End If
    End Sub
End Class
