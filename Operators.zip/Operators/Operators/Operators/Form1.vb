﻿Public Class Form1

    Private mstrOp As String = "+"
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        mstrOp = "+" 'sets the varible equal to the + symbol
        lblOp.Text = mstrOp
    End Sub

    Private Sub btnSubtract_Click(sender As Object, e As EventArgs) Handles btnSubtract.Click
        mstrOp = "-" 'sets the varible equal to the - symbol
        lblOp.Text = mstrOp
    End Sub

    Private Sub btnMultiply_Click(sender As Object, e As EventArgs) Handles btnMultiply.Click
        mstrOp = "*" 'sets the varible equal to the * symbol
        lblOp.Text = mstrOp
    End Sub

    Private Sub btnDivide_Click(sender As Object, e As EventArgs) Handles btnDivide.Click
        mstrOp = "/" 'sets the varible equal to the / symbol
        lblOp.Text = mstrOp
    End Sub

    Private Sub btnEqual_Click(sender As Object, e As EventArgs) Handles btnEqual.Click
        Dim pdblTotal As Double 'holds the total
        Dim pdblNum1 As Double 'holds the first number
        Dim pdblNum2 As Double 'holds the second number
        'get the numbers from the text boxes and put them into the varibles
        pdblNum1 = CDec(txtNum1.Text) ' converts the characters into values and puts its into the varible
        pdblNum2 = CDec(txtNum2.Text) ' converts the characters into values and puts its into the varible
        'figures out whihc operations to perform

        If mstrOp = "+" Then 'if the conditions are true then do the following statements
            pdblTotal = pdblNum1 + pdblNum2 'adds the numbers together and puts the total into the varible

        ElseIf mstrOp = "-" Then 'if the conditions are true then do the following statements
            pdblTotal = pdblNum1 - pdblNum2 'subtracts the numbers together and puts the total into the varible

        ElseIf mstrOp = "*" Then 'if the conditions are true then do the following statements
            pdblTotal = pdblNum1 * pdblNum2 'multpiles the numbers together and puts the total into the varible

        Else
            pdblTotal = pdblNum1 / pdblNum2 'divides the numbers together and puts the total into the varible

        End If

        lblTotal.Text = pdblTotal ' displays the total

    End Sub

    Private Sub txtNum1_TextChanged(sender As Object, e As EventArgs) Handles txtNum1.TextChanged

    End Sub

    Private Sub txtNum1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNum1.KeyPress
        If e.KeyChar = "+" Then 'checks to see if + was last key press
            mstrOp = "+" 'sets the varible equal to the + symbol
            lblOp.Text = mstrOp
            e.Handled = True 'we have taken care of the keypress and the computer can ignore the keypress
            txtNum2.Text = "" 'blanks out txtNum2
            lblTotal.Text = "" 'blanks out lblTotal
            txtNum2.Focus() 'puts the cursur into txtNum2
        ElseIf e.KeyChar = "-" Then
            mstrOp = "-" 'sets the varible equal to the - symbol
            lblOp.Text = mstrOp
            e.Handled = True 'we have taken care of the keypress and the computer can ignore the keypress
            txtNum2.Text = "" 'blanks out txtNum2
            lblTotal.Text = "" 'blanks out lblTotal
            txtNum2.Focus() 'puts the cursur into txtNum2
        ElseIf e.KeyChar = "*" Then
            mstrOp = "*" 'sets the varible equal to the * symbol
            lblOp.Text = mstrOp
            e.Handled = True 'we have taken care of the keypress and the computer can ignore the keypress
            txtNum2.Text = "" 'blanks out txtNum2
            lblTotal.Text = "" 'blanks out lblTotal
            txtNum2.Focus() 'puts the cursur into txtNum2
        ElseIf e.KeyChar = "/" Then
            mstrOp = "/" 'sets the varible equal to the / symbol
            lblOp.Text = mstrOp
            e.Handled = True 'we have taken care of the keypress and the computer can ignore the keypress
            txtNum2.Text = "" 'blanks out txtNum2
            lblTotal.Text = "" 'blanks out lblTotal
            txtNum2.Focus() 'puts the cursur into txtNum2
        End If
    End Sub
End Class
