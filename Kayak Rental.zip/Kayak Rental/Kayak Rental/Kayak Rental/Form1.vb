﻿Public Class Form1

    Const dblTaxRate As Double = 0.07

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Dim intHours As Integer
        Dim dblRentalRate As Double
        Dim dblAccesories As Double

        Dim dblBasicRental As Double
        Dim dblSubtotal As Double
        Dim dblSalesTax As Double
        Dim dblFinalTotal As Double

        'convert the input fields
        intHours = CInt(txtHours.Text)
        dblRentalRate = CDbl(txtRentalRate.Text)
        dblAccesories = CDbl(txtAccessories.Text)

        'Do the calculations
        dblBasicRental = intHours * dblRentalRate
        dblSubtotal = dblBasicRental + dblAccesories
        dblSalesTax = dblSubtotal * dblTaxRate
        dblFinalTotal = dblSubtotal + dblSalesTax

        'Display teh results
        lblBasicRental.Text = dblBasicRental.ToString("n")
        lblAccessories.Text = dblAccesories.ToString("n")
        lblSubtotal.Text = dblSubtotal.ToString("n")
        lblSalesTax.Text = dblSalesTax.ToString("n")
        lblFinalTotal.Text = dblFinalTotal.ToString("n")


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close() 'closes the program
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        txtAccessories.Clear()
        txtHours.Clear()
        txtRentalRate.Clear()

        lblBasicRental.Text = String.Empty
        lblAccessories.Text = String.Empty
        lblSubtotal.Text = String.Empty
        lblSalesTax.Text = String.Empty
        lblFinalTotal.Text = String.Empty

    End Sub
End Class
