﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtGas.Text = "" 'clears out the text
        txtMiles.Text = "" 'clears out the text
        lblTotal.Text = "" 'clears out the text
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim pdblTotal As Double 'holds the total
        Dim pdblGas As Double 'holds the first number
        Dim pdblMiles As Double 'holds the second number
        'get the numbers from the text boxes and put them into the varibles
        pdblGas = CDec(txtGas.Text) ' converts the characters into values and puts its into the varible
        pdblMiles = CDec(txtMiles.Text) ' converts the characters into values and puts its into the varible
        pdblTotal = pdblMiles / pdblGas 'divides the numbers together and puts the total into the varible

        lblTotal.Text = pdblTotal ' displays the total

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close() 'close the program
    End Sub
End Class
